public interface SidedObject{
	public int displaySides();
}