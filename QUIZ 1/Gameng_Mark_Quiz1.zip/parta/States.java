package MainClass.OtherClasses;
public enum States{ILLINOIS,NEW_YORK,FLORIDA,CALIFORNIA,NONE};