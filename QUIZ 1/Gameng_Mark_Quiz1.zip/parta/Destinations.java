package MainClass.OtherClasses;
public enum Destinations{CHICAGO,NEW_YORK,SOME_CITY,TAMPA,MIAMI,LOS_ANGELES,SAN_FRANCISCO,NONE};