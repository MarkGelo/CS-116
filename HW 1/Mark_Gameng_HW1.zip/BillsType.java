package Client.Services;
	public enum BillsType {School, Restaurant, Clothing, Other;}
