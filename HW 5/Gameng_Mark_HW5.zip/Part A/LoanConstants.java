public interface LoanConstants{
	//inteface variables are public, static, final, by default
	int shortTerm = 1;
	int mediumTerm = 3;
	int longTerm = 5;
	String companyName = "Sanchez Construction Loan Co.";
	double maximumLoan = 100000;
}