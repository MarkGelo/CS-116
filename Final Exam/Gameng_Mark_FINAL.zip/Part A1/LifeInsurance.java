public class LifeInsurance extends Insurance{
	
	public LifeInsurance(){
		super();
		this.setCost();
	}
	public void setCost(){
		super.setCost(40);
	}
}