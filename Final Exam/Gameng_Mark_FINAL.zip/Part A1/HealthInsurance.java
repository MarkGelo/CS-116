public class HealthInsurance extends Insurance{
	
	public HealthInsurance(){
		super();
		this.setCost();
	}
	public void setCost(){
		super.setCost(180);
	}
}